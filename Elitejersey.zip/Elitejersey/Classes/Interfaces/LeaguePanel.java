package Interfaces;

public interface LeaguePanel {
    void showPanel(String productTitle, String imagePath, String classPrices);
}
