import Classes.*;
import Interfaces.*;
public class Start {

    public static void main(String[] args) {
        Home frame = new Home();
        frame.setVisible(true);
    
    }
}
    